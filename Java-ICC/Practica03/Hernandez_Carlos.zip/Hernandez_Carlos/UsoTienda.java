public class UsoTienda {
  public static void main(String[] args) {
    Tienda tienda = new Tienda();
    tienda.ejecutaPrograma();
  }
  
}
