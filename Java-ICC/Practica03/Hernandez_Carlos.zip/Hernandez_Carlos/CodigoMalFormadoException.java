
public class CodigoMalFormadoException extends Exception{
  public CodigoMalFormadoException(String message){
    super(message);
  }
  
}
