public class CapacidadInsuficienteException extends Exception {
  public CapacidadInsuficienteException(String message){
    super(message);
  }
}
