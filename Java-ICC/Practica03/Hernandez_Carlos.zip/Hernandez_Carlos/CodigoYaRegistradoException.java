
public class CodigoYaRegistradoException extends Exception{
  public CodigoYaRegistradoException (String message){
    super(message);
  }
}
