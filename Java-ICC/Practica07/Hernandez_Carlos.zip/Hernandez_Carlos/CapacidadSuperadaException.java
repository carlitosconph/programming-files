public class CapacidadSuperadaException extends Exception{
  public CapacidadSuperadaException(String message){
    super(message);
  }
}
