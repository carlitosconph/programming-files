
public class CodigoNoExistenteException extends Exception{
  public CodigoNoExistenteException(String message){
    super(message);
  }
  
}
